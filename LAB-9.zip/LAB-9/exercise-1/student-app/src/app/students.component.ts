import { Component } from '@angular/core';

@Component({
  selector: 'students',
  standalone: true,
  imports: [],
  template: `
    <h2>{{ getTitle() }}</h2>
    <p>{{ getCurrentDate() }}</p>
  `,
})
export class StudentsComponent {
  title = 'My List of Students';

  getTitle(): string {
    return this.title;
  }

  getCurrentDate(): string {
    return new Date().toDateString();
  }
}
