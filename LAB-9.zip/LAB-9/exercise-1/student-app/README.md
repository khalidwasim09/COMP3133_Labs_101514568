# Student app (Lab 9)

Small Angular practice app for COMP 3133 — components, a bit of CLI, and simple template binding.

## Run it

From this folder:

```bash
npm install
npx ng serve
```

Open **http://localhost:4200** in your browser. Edit files and save; the page refreshes on its own.

If you have Angular CLI installed globally, you can use `ng serve` instead of `npx ng serve`.

## What’s in here

- **`students.component.ts`** — the hand-built `StudentsComponent` (`<students></students>`), with title + date helpers for the binding exercise.
- **`student/`** — the extra component created with `ng generate component student` so you can compare CLI output to the manual file.

## Build (optional)

```bash
npx ng build
```

Output goes to `dist/`.

## Tests (optional)

```bash
npx ng test
```

That’s enough to get going. For Angular docs, see [angular.dev](https://angular.dev).
